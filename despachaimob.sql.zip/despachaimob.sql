-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 13-Jun-2021 às 15:35
-- Versão do servidor: 10.4.13-MariaDB
-- versão do PHP: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `despachaimob`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `nacionalidade` varchar(80) DEFAULT '"',
  `nascimento` date NOT NULL,
  `rg` varchar(255) NOT NULL,
  `d_expedicao` date NOT NULL,
  `o_expedidor` varchar(150) NOT NULL,
  `profissao` varchar(255) DEFAULT '"',
  `ass_cartorio` varchar(150) DEFAULT '"',
  `cep` varchar(10) DEFAULT '"',
  `logradouro` varchar(255) DEFAULT '"',
  `numero` varchar(100) DEFAULT '"',
  `complemento` varchar(150) DEFAULT '"',
  `bairro` varchar(150) DEFAULT '"',
  `cidade` varchar(255) DEFAULT '"',
  `uf` varchar(2) DEFAULT '"',
  `email_1` varchar(255) NOT NULL,
  `email_2` varchar(255) DEFAULT '"',
  `celular` varchar(150) NOT NULL,
  `residencia` varchar(150) DEFAULT '"',
  `comercial` varchar(150) DEFAULT '"',
  `recado` varchar(150) DEFAULT '"',
  `tipo_regime` varchar(50) NOT NULL,
  `regime` varchar(255) DEFAULT '"',
  `data_casamento` date DEFAULT NULL,
  `cartorio_casamento` varchar(255) DEFAULT NULL,
  `matricula_certidao` varchar(255) DEFAULT NULL,
  `nome_conjuge` varchar(255) DEFAULT '"',
  `cpf_conjuge` varchar(20) DEFAULT '"',
  `nacionalidade_conjuge` varchar(150) DEFAULT '"',
  `nascimento_conjuge` date DEFAULT NULL,
  `rg_conjuge` varchar(200) DEFAULT '"',
  `d_expedicao_conjuge` date DEFAULT NULL,
  `o_expedidor_conjuge` varchar(255) DEFAULT '"',
  `profissao_conjuge` varchar(255) DEFAULT '"',
  `ass_cartorio_conjuge` varchar(255) DEFAULT '"',
  `telefone_conjuge` varchar(50) DEFAULT NULL,
  `email_conjuge` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `compradores`
--

CREATE TABLE `compradores` (
  `id_comprador` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_cliente_pj` int(11) NOT NULL,
  `cpf_cnpj_comprador` varchar(20) NOT NULL,
  `num_processo_comprador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `compradores_procuradores`
--

CREATE TABLE `compradores_procuradores` (
  `id_proc_comprador` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_cliente_pj` int(11) NOT NULL,
  `cpf_cnpj_proc_comprador` varchar(20) NOT NULL,
  `num_processo_proc_comprador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `imoveis`
--

CREATE TABLE `imoveis` (
  `id_imovel` int(11) NOT NULL,
  `cep` varchar(12) NOT NULL,
  `logradouro` varchar(255) NOT NULL,
  `numero` varchar(150) DEFAULT NULL,
  `complemento` varchar(150) DEFAULT NULL,
  `bairro` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `uf` varchar(2) NOT NULL,
  `iptu` varchar(150) DEFAULT NULL,
  `cartorio` varchar(255) NOT NULL,
  `matricula` varchar(150) NOT NULL,
  `v_venda` varchar(255) NOT NULL,
  `v_condominio` varchar(150) DEFAULT NULL,
  `suites` varchar(10) DEFAULT NULL,
  `vazio` varchar(1) NOT NULL,
  `opcao_vazio` varchar(20) DEFAULT NULL,
  `garagem` varchar(10) DEFAULT NULL,
  `elevador` varchar(10) DEFAULT NULL,
  `quartos` varchar(10) DEFAULT NULL,
  `p_referencia` varchar(255) DEFAULT NULL,
  `observacao` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pjclientes`
--

CREATE TABLE `pjclientes` (
  `id_cliente_pj` int(11) NOT NULL,
  `razao_social` varchar(255) NOT NULL,
  `nome_fantasia` varchar(255) DEFAULT '''''',
  `cnpj` varchar(20) NOT NULL,
  `insc_estadual` varchar(12) NOT NULL,
  `data_abertura` date NOT NULL,
  `cep` varchar(10) DEFAULT '''''',
  `logradouro` varchar(255) DEFAULT '''''',
  `numero` varchar(100) DEFAULT '''''',
  `complemento` varchar(150) DEFAULT '''''',
  `bairro` varchar(255) DEFAULT '''''',
  `cidade` varchar(255) DEFAULT '''''',
  `uf` varchar(2) DEFAULT '''''',
  `email_1` varchar(255) NOT NULL,
  `email_2` varchar(255) DEFAULT '''''',
  `telefone_1` varchar(150) NOT NULL DEFAULT ' ',
  `telefone_2` varchar(150) DEFAULT '''''',
  `nome_socio_1` varchar(255) NOT NULL,
  `cpf_socio_1` varchar(20) NOT NULL,
  `nacionalidade_socio_1` varchar(80) DEFAULT NULL,
  `nascimento_socio_1` date DEFAULT NULL,
  `rg_socio_1` varchar(50) DEFAULT ' ',
  `d_expedicao_socio_1` date DEFAULT NULL,
  `o_expedidor_socio_1` varchar(30) DEFAULT NULL,
  `cep_socio_1` varchar(10) DEFAULT '''''',
  `logradouro_socio_1` varchar(255) DEFAULT '''''',
  `numero_socio_1` varchar(100) DEFAULT '''''',
  `complemento_socio_1` varchar(150) DEFAULT '''''',
  `bairro_socio_1` varchar(150) DEFAULT '''''',
  `cidade_socio_1` varchar(255) DEFAULT '''''',
  `uf_socio_1` varchar(2) DEFAULT '''''',
  `profissao_socio_1` varchar(255) DEFAULT ' ',
  `estado_civil_socio_1` varchar(50) DEFAULT NULL,
  `ass_cartorio_socio_1` varchar(255) DEFAULT NULL,
  `celular_socio_1` varchar(50) DEFAULT '''''',
  `email_socio_1` varchar(255) DEFAULT '''''',
  `nome_socio_2` varchar(255) DEFAULT '''''',
  `cpf_socio_2` varchar(20) DEFAULT '''''',
  `nacionalidade_socio_2` varchar(80) DEFAULT '''''',
  `nascimento_socio_2` date DEFAULT NULL,
  `rg_socio_2` varchar(50) DEFAULT NULL,
  `d_expedicao_socio_2` date DEFAULT NULL,
  `o_expedidor_socio_2` varchar(50) DEFAULT NULL,
  `cep_socio_2` varchar(10) DEFAULT '''''',
  `logradouro_socio_2` varchar(255) DEFAULT '''''',
  `numero_socio_2` varchar(100) DEFAULT '''''',
  `complemento_socio_2` varchar(150) DEFAULT '''''',
  `bairro_socio_2` varchar(150) DEFAULT '''''',
  `cidade_socio_2` varchar(255) DEFAULT '''''',
  `uf_socio_2` varchar(2) DEFAULT '''''',
  `profissao_socio_2` varchar(255) DEFAULT '''''',
  `estado_civil_socio_2` varchar(50) DEFAULT '''''',
  `ass_cartorio_socio_2` varchar(255) DEFAULT NULL,
  `celular_socio_2` varchar(50) DEFAULT '''''',
  `email_socio_2` varchar(255) DEFAULT '''''',
  `nome_socio_3` varchar(255) DEFAULT '''''',
  `cpf_socio_3` varchar(20) DEFAULT '''''',
  `nacionalidade_socio_3` varchar(80) DEFAULT '''''',
  `nascimento_socio_3` date DEFAULT NULL,
  `rg_socio_3` varchar(100) DEFAULT NULL,
  `d_expedicao_socio_3` date DEFAULT NULL,
  `o_expedidor_socio_3` varchar(50) DEFAULT NULL,
  `cep_socio_3` varchar(10) DEFAULT '''''',
  `logradouro_socio_3` varchar(255) DEFAULT '''''',
  `numero_socio_3` varchar(100) DEFAULT '''''',
  `complemento_socio_3` varchar(100) DEFAULT '''''',
  `bairro_socio_3` varchar(150) DEFAULT '''''',
  `cidade_socio_3` varchar(255) DEFAULT '''''',
  `uf_socio_3` varchar(2) DEFAULT '''''',
  `profissao_socio_3` varchar(255) DEFAULT '''''',
  `estado_civil_socio_3` varchar(50) DEFAULT '''''',
  `ass_cartorio_socio_3` varchar(255) DEFAULT NULL,
  `celular_socio_3` varchar(50) DEFAULT '''''',
  `email_socio_3` varchar(255) DEFAULT '''''',
  `nome_socio_4` varchar(255) DEFAULT '''''',
  `cpf_socio_4` varchar(20) DEFAULT '''''',
  `nacionalidade_socio_4` varchar(80) DEFAULT '''''',
  `nascimento_socio_4` date DEFAULT NULL,
  `rg_socio_4` varchar(100) DEFAULT NULL,
  `d_expedicao_socio_4` date DEFAULT NULL,
  `o_expedidor_socio_4` varchar(50) DEFAULT NULL,
  `cep_socio_4` varchar(10) DEFAULT '''''',
  `logradouro_socio_4` varchar(255) DEFAULT '''''',
  `numero_socio_4` varchar(100) DEFAULT '''''',
  `complemento_socio_4` varchar(150) DEFAULT '''''',
  `bairro_socio_4` varchar(150) DEFAULT '''''',
  `cidade_socio_4` varchar(255) DEFAULT '''''',
  `uf_socio_4` varchar(2) DEFAULT '''''',
  `profissao_socio_4` varchar(255) DEFAULT '''''',
  `estado_civil_socio_4` varchar(50) DEFAULT '''''',
  `ass_cartorio_socio_4` varchar(255) DEFAULT NULL,
  `celular_socio_4` varchar(50) DEFAULT '''''',
  `email_socio_4` varchar(255) DEFAULT ''''''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `processos`
--

CREATE TABLE `processos` (
  `id_processo` int(11) NOT NULL,
  `numero_processo` int(11) NOT NULL,
  `data_cadastro_processo` date NOT NULL,
  `id_imovel_processo` int(11) NOT NULL DEFAULT 0,
  `matricula_processo` varchar(150) NOT NULL DEFAULT '0',
  `indicacao` varchar(255) DEFAULT '0',
  `honorarios` varchar(255) DEFAULT '0',
  `certidoes` varchar(255) DEFAULT '0',
  `outros` varchar(255) DEFAULT '0',
  `obs` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tarefas`
--

CREATE TABLE `tarefas` (
  `id` int(11) NOT NULL,
  `id_status` int(11) NOT NULL DEFAULT 1,
  `tarefa` text NOT NULL,
  `data_cadastrado` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tarefa_status`
--

CREATE TABLE `tarefa_status` (
  `id` int(11) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendedores`
--

CREATE TABLE `vendedores` (
  `id_vendedor` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_cliente_pj` int(11) NOT NULL,
  `cpf_cnpj_vendedor` varchar(20) NOT NULL,
  `num_processo_vendedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendedores_procuradores`
--

CREATE TABLE `vendedores_procuradores` (
  `id_proc_vendedor` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_cliente_pj` int(11) NOT NULL,
  `cpf_cnpj_proc_vendedor` varchar(20) NOT NULL,
  `num_processo_proc_vendedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Índices para tabela `compradores`
--
ALTER TABLE `compradores`
  ADD PRIMARY KEY (`id_comprador`),
  ADD KEY `clientes` (`id_cliente`),
  ADD KEY `pjclientes` (`id_cliente_pj`);

--
-- Índices para tabela `compradores_procuradores`
--
ALTER TABLE `compradores_procuradores`
  ADD PRIMARY KEY (`id_proc_comprador`),
  ADD KEY `clientes` (`id_cliente`),
  ADD KEY `pjclientes` (`id_cliente_pj`);

--
-- Índices para tabela `imoveis`
--
ALTER TABLE `imoveis`
  ADD PRIMARY KEY (`id_imovel`);

--
-- Índices para tabela `pjclientes`
--
ALTER TABLE `pjclientes`
  ADD PRIMARY KEY (`id_cliente_pj`);

--
-- Índices para tabela `processos`
--
ALTER TABLE `processos`
  ADD PRIMARY KEY (`id_processo`);

--
-- Índices para tabela `tarefas`
--
ALTER TABLE `tarefas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_status` (`id_status`);

--
-- Índices para tabela `tarefa_status`
--
ALTER TABLE `tarefa_status`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `vendedores`
--
ALTER TABLE `vendedores`
  ADD PRIMARY KEY (`id_vendedor`),
  ADD KEY `clientes` (`id_cliente`),
  ADD KEY `pjclientes` (`id_cliente_pj`);

--
-- Índices para tabela `vendedores_procuradores`
--
ALTER TABLE `vendedores_procuradores`
  ADD PRIMARY KEY (`id_proc_vendedor`),
  ADD KEY `clientes` (`id_cliente`),
  ADD KEY `pjclientes` (`id_cliente_pj`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `compradores`
--
ALTER TABLE `compradores`
  MODIFY `id_comprador` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `compradores_procuradores`
--
ALTER TABLE `compradores_procuradores`
  MODIFY `id_proc_comprador` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `imoveis`
--
ALTER TABLE `imoveis`
  MODIFY `id_imovel` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pjclientes`
--
ALTER TABLE `pjclientes`
  MODIFY `id_cliente_pj` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `processos`
--
ALTER TABLE `processos`
  MODIFY `id_processo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tarefas`
--
ALTER TABLE `tarefas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tarefa_status`
--
ALTER TABLE `tarefa_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `vendedores`
--
ALTER TABLE `vendedores`
  MODIFY `id_vendedor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `vendedores_procuradores`
--
ALTER TABLE `vendedores_procuradores`
  MODIFY `id_proc_vendedor` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `tarefas`
--
ALTER TABLE `tarefas`
  ADD CONSTRAINT `tarefas_ibfk_1` FOREIGN KEY (`id_status`) REFERENCES `tarefa_status` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
